#!/usr/bin/env python3
#导入math包中的sqrt（根号）方法
from math import sqrt

print("{0:.2f}".format((sqrt(144)+2**10)/3))
print("{0:.2f}".format(sqrt(2**10+2**8)/2))
print("{0:.2f}".format((sqrt(2)+100)/2**3))



