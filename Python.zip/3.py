#!/usr/bin/env python3

from datetime import date,datetime

today= date.today();
print(today)
print(today.year)
print(today.month)
print(today.day)
time = datetime.today()
print(time)
print(today.strftime('%B %d,%Y'))