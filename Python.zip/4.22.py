#!/usr/bin/env python3
import pandas as pd
import sys
input_file = sys.argv[1]
output_file = sys.argv[2]
data_frame = pd.read_excel(input_file, 'all_data_all_workbooks', index_col=None)
data_frame_column_by_name = data_frame.loc[:, ['Customer Name', 'Sale Amount','Purchase Date']]
writer = pd.ExcelWriter(output_file)
data_frame_column_by_name.to_excel(writer, sheet_name='all_data_all_workbooks',\
index=False)
writer.save()