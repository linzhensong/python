#!/usr/bin/env python3

#字符串的第一题
string1="One World "
string2="One Dream."
string3=string1+string2
count = len(string3)
print(count)
newString3 = string3.replace(" ","-")
print(newString3)


#字符串的第二题
string1="one two thre four five six seven eight nine ten"
string1 = string1.upper()
print(string1)
stringAll = string1.split(" ")
for string in stringAll:
    print(string)


#字符串的第三题
list1=["one","two","thr","four","five"]
list2=["six","seven","eight","nine","ten"]
list3=list1+list2
count = len(list3)
for tmp in list3:
    temp =tmp.capitalize()
    print(temp)